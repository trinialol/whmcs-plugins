# Clean up tables for the integration

DROP TABLE IF EXISTS cloudflare_plans;
DROP TABLE IF EXISTS cloudflare_zone;
DROP TABLE IF EXISTS cloudflare_log;
DROP TABLE IF EXISTS cloudflare_ulog;
